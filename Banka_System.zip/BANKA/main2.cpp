#include<iostream>
#include<string>
#include <cstring>
#include"ekran.h"
#include "musteri.h"
using namespace std;
int main()
{
   Ekran ekran;
   ekran.anaSayfa();
//---------------------------------------------------------------------  




//---------------------------------------------------------------------
/*

   kullaniciIslem:
   ekran.kullaniciIslem();
      switch(secim)
      {
         case 1:
            cout<<"yatirmak istediginiz tutari giriniz"<<endl;
            musteri.paraCek(tutar);
            tutar=0;
            goto kullaniciIslem;
            break;

         case 2:
            cout<<"cekmek istediginiz tutari giriniz"<<endl;
            musteri.paraYatir(tutar);
            tutar=0;
            goto kullaniciIslem;
            break;

         case 3:
            cout<<"eski sifrenizi giriniz"<<endl;
            cin>>eskisifre;
            musteri.sifreDegistir(eskisifre);
            cout<<"yeni sifrenizi giriniz"<<endl;
            cin>>yenisifre;
            goto kullaniciIslem;
            break;

         case 4:
            goto anaSayfa;
            break;

         case 5:
           return 0;
           break;

         default:
            cerr<<"HATA:gecersiz tuslama"<<endl;
            goto kullaniciIslem;
            break;
      }
*/
}
